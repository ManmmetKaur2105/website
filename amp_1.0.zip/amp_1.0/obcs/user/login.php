<?php
session_start();
error_reporting(0);
include "connection.php";

?>
<!doctype html>
<html>
<head>
       <title>Login | Air MP</title>
   
     <link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/font-awesome.min.css">
      <link rel="stylesheet" href="css/form.css">
      <link rel="stylesheet" href="style.css">
   </head>

<body class="materialdesign">

<div class="breadcome-area mg-b-30 small-dn">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="breadcome-list shadow-reset">
                        <div class="row">
                           
                            <div class="col-lg-12">
                                <ul class="breadcome-menu">
                                    <li><a href="../index.php">HOME</a> <span class="bread-slash">/</span>
                                    </li>
                                    <li><span class="bread-blod">LOGIN PAGE</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

            <!-- login Start-->
            <div class="login-form-area mg-t-30 mg-b-40">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-4"></div>
                        <form class="adminpro-form" method="post" name="login">
                            <div class="col-lg-4">
                                <div class="login-bg">
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="logo">
                                                <h3 style="font-weight: bold;color: green">AIR MP</h3>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <div class="login-title">
                                                <h1 style="color: red; text-align:center;">USER LOGIN FORM</h1>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p><b>USERNAME</b></p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="text" name="username" required="" />
                                                <i class="fa fa-mobile login-user" aria-hidden="true"></i>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-4">
                                            <div class="login-input-head">
                                                <p><b>PASSWORD:</b></p>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-input-area">
                                                <input type="password" name="password" required="true" />
                                                <i class="fa fa-lock login-user"></i>
                                            </div>
                                         </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-lg-4">

                                        </div>
                                        <div class="col-lg-8">
                                            <div class="login-button-pro">
                                               
                                                <button type="submit" class="login-button login-button-lg" name="login">LOG IN</button>

                                            </div>
                                            <p><a href="register.php">Don't have an account ? Register Here</a></p>
                                        </div>
                                           <p style="text-align: center;"><a href="../index.php">Back Home!!!</a></p>
                                    </div>
                                </div>
                            </div>
                        </form>
                        
                    </div>
                </div>
            </div>
<?php
    if(isset($_POST['login'])){
        $count=0;
        $res=mysqli_query($db,"SELECT * FROM `register` WHERE username='$_POST[username]' && password='$_POST[password]';");

        $row= mysqli_fetch_assoc($res);

        $count= mysqli_num_rows($res);

        if($count==0){
            ?>
            <div style="width: 700px; margin-left: 420px; margin-top: 20px; background-color: #ec0d0d; color: white;">
                <strong> The username and password doesn't matched. </strong>
            </div>
            <?php
        }
        else{
            $_SESSION['login_user'] = $_POST['username'];
            ?>
            <script>
                window.location="afterlogin.php"
            </script>
            <?php
        }
    } 
?>
</body>
</html>