<?php
include "connection.php";
?>
<!doctype html>
<html>

<head>
   
    <title> Book A Flight | Air MP </title>
   
    
    <link rel="stylesheet" href="css/bootstrap.min.css">
   
    <link rel="stylesheet" href="style.css">
    
</head>

<body class="materialdesign">
  
               <div class="breadcome-area mg-b-30 small-dn">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="breadcome-list shadow-reset">
                                <div class="row">
                                   
                                    <div class="col-lg-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="dashboard.php">HOME</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">BOOK FLIGHT</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
            <!-- Basic Form Start -->
            <div class="basic-form-area mg-b-15">
                <div class="container-fluid">
                   
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="sparkline12-list shadow-reset mg-t-30">
                                <div class="sparkline12-hd">
                                    <div class="main-sparkline12-hd">
                                        <h1>BOOK YOUR FLIGHT</h1>
                                        <div class="sparkline12-outline-icon">
                                            <span class="sparkline12-collapse-link"><i class="fa fa-chevron-up"></i></span>
                                            <span><i class="fa fa-wrench"></i></span>
                                            <span class="sparkline12-collapse-close"><i class="fa fa-times"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="sparkline12-graph">
                                    <div class="basic-login-form-ad">
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="all-form-element-inner">
                                                    
                                                    <form method="post">
                                                        
                                                        <div class="form-group-inner">
                                                            <div class="row">
                                                                <div class="col-lg-3">
                                                                    <label class="login2 pull-right pull-right-pro">FROM:</label>
                                                                </div>
                                                                <div class="col-lg-9">
                                                                    <select>
                                                                        <option value = "Select"> --Select--   
                                                                        </option>  
                                                                        <option value = "Bhopal"> Bhopal  
                                                                        </option>  
                                                                        <option value = "Jabalpur"> Jabalpur   
                                                                        </option>  
                                                                        <option value = "Indore"> Indore
                                                                        </option>  
                                                                        <option value = "Gwalior"> Gwalior
                                                                        </option>  
                                                                        </select>  
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="form-group-inner">
                                                            <div class="row">
                                                                <div class="col-lg-3">
                                                                    <label class="login2 pull-right pull-right-pro">TO:</label>
                                                                </div>
                                                                <div class="col-lg-9">
                                                                    <select>
                                                                        <option value = "Select"> --Select--   
                                                                        </option>  
                                                                        <option value = "Bhopal"> Bhopal  
                                                                        </option>  
                                                                        <option value = "Jabalpur"> Jabalpur   
                                                                        </option>  
                                                                        <option value = "Indore"> Indore
                                                                        </option>  
                                                                        <option value = "Gwalior"> Gwalior
                                                                        </option>  
                                                                        </select>  
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="form-group-inner">
                                                            <div class="row">
                                                                <div class="col-lg-3">
                                                                    <label class="login2 pull-right pull-right-pro">DATE:</label>
                                                                </div>
                                                                <div class="col-lg-9">

                                                                    <input type="date" class="form-control" name="date" value="" required="true" />
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="form-group-inner">
                                                            <div class="row">
                                                                <div class="col-lg-3">
                                                                    <label class="login2 pull-right pull-right-pro">FLIGHTS:</label>
                                                                </div>
                                                                <div class="col-lg-9">
                                                                    <select>
                                                                        <option value = "Select"> --Select--   
                                                                        </option>  
                                                                        <option value = "Airbus A340-200"> Airbus A340-200  
                                                                        </option>  
                                                                        <option value = "Airbus A350-300"> Airbus A350-300   
                                                                        </option>  
                                                                        <option value = "Airbus A360-400"> Airbus A360-400
                                                                        </option>  
                                                                        <option value = "Airbus A360-500"> Airbus A360-500
                                                                        </option>  
                                                                        </select>  
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="form-group-inner">
                                                            <div class="row">
                                                                <div class="col-lg-3">
                                                                    <label class="login2 pull-right pull-right-pro">Class:</label>
                                                                </div>
                                                                <div class="col-lg-9">
                                                                    <select>
                                                                        <option value = "Select"> --Select--   
                                                                        </option>  
                                                                        <option value = "Business"> Business  
                                                                        </option>  
                                                                        <option value = "Economy"> Economy   
                                                                        </option>    
                                                                        </select>  
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="form-group-inner">
                                                            <div class="row">
                                                                <div class="col-lg-3">
                                                                    <label class="login2 pull-right pull-right-pro">NO OF PASSENGERS:</label>
                                                                </div>
                                                                <div class="col-lg-9">
                                                                    <input type="number" class="form-control" required="true" value="" name="number_of_passengers"/>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <h2 style="text-align: center;">PASSENGER DETAILS</h2>

                                                        <div class="row">
                                                            <div class="col-lg-4">
                                                            <div class="login-input-head">
                                                                <p><b>NAME:</b></p>
                                                            </div>
                                                            </div>
                                                            <div class="col-lg-8">
                                                            <div class="login-input-area">
                                                                <input type="char" name="sname" required="true" />
                                                                <i class="fa fa-user login-user"></i>
                                                            </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                            <div class="col-lg-4">
                                                            <div class="login-input-head">
                                                                <p><b>AGE:</b></p>
                                                            </div>
                                                            </div>
                                                            <div class="col-lg-8">
                                                            <div class="login-input-area">
                                                                <input type="int" name="age" required="true" />
                                                                <i class="fa fa-user login-user"></i>
                                                            </div>
                                                            </div>
                                                        </div>

                                                        <div class="row">
                                                        <div class="col-lg-4">
                                                                <div class="login-input-head">
                                                                    <p><b>GENDER:</b></p>
                                                                </div>
                                                            </div>
                                                            <div class="col-lg-8">
                                                                <div class="login-input-area">
                                                                    <input type="radio" name="gender" value="Male" maxlength="10" pattern="[0-9]+" required="true" />Male
                                                                    <input type="radio" name="gender" value="Female" maxlength="10" pattern="[0-9]+" required="true" />Female
                                                                    <i class="fa fa-mobile login-user" aria-hidden="true"></i>
                                                                </div>
                                                        </div>
                                                        </div>

                                                            <div class="form-group-inner">
                                                            <div class="row">
                                                                <div class="col-lg-3">
                                                                    <label class="login2 pull-right pull-right-pro">ID NUMBER:</label>
                                                                </div>
                                                                <div class="col-lg-9">
                                                                    <input type="int" class="form-control" required="true" value="" name="id_number" maxlength="10" pattern="[0-9]+" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                    
                                                        <div class="form-group-inner">
                                                            <div class="login-btn-inner">
                                                                <div class="row">
                                                                    <div class="col-lg-3"></div>
                                                                    <div class="col-lg-9">
                                                                        <div class="login-horizental cancel-wp pull-left">
                                                                            <button class="btn btn-sm btn-primary login-submit-cs" type="submit" name="pay">Proceed To Pay</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <?php
    if(isset($_POST['submit'])){
        $count=0;
        $sql='SELECT username from register';
        $res=mysqli_query($db,$sql);

        while($row=mysqli_fetch_assoc($res)){
            if($row['username']==$_POST['username']){
                $count=$count+1;
            }
        }

    if($count==0){
        mysqli_query($db,"INSERT INTO `booking` VALUES ('$_POST[sname]','$_POST[dob]','$_POST[gender]',
        '$_POST[id]','$_POST[id_number]','$_POST[username]',
        '$_POST[password]')");
        ?>
            <script type="text/javascript">
                alert("Flight Details Done");
                window.location="pay.php";
            </script>
        <?php
        }
        else{
        ?>
            <script>
                alert("The username alerady exists");
            </script>
        <?php
        }
    }  
?>     
            
</body>

</html>