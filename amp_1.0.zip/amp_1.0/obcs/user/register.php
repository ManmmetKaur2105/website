<?php 
session_start();
// error_reporting(0);
include "connection.php";
?>

<!doctype html>
<html>
<head>
    <title>Registeration | Air MP </title>

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/form.css">
    <link rel="stylesheet" href="style.css">
</head>

<body class="materialdesign">
<div class="breadcome-area mg-b-30 small-dn">
<div class="container-fluid">
<div class="row">
<div class="col-lg-12">
<div class="breadcome-list shadow-reset">
<div class="row">
<div class="col-lg-12">
    <ul class="breadcome-menu">
        <li><a href="../index.php">HOME</a> <span class="bread-slash">/</span>
        </li>
        <li><span class="bread-blod">REGISTERATION FORM</span>
        </li>
    </ul>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<div class="wrapper-pro">
   
<div class="login-form-area mg-t-30 mg-b-15">
<div class="container-fluid">
<div class="row">
<div class="col-lg-3"></div>
<form class="adminpro-form" method="post">
<div class="col-lg-6">
<div class="login-bg">
<div class="row">
    <div class="col-lg-12">
        <div class="logo">
            <h3 style="font-weight: bold;color: green; text-align:center;">AIR MP</h3>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="login-title">
            <h1 style="color: red; text-align:center;">USER REGISTERATION FORM</h1>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-4">
        <div class="login-input-head">
            <p><b>NAME:</b></p>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="login-input-area">
            <input type="char" name="sname" required="true" />
            <i class="fa fa-user login-user"></i>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-4">
        <div class="login-input-head">
            <p><b>DATE OF BIRTH:</p>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="login-input-area">
            <input type="date" name="dob" required="true" />
            <i class="fa fa-user login-user"></i>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-4">
        <div class="login-input-head">
            <p><b>GENDER:</b></p>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="login-input-area">
            <input type="radio" name="gender" value="Male" maxlength="10" pattern="[0-9]+" required="true" />Male
            <input type="radio" name="gender" value="Female" maxlength="10" pattern="[0-9]+" required="true" />Female
            <i class="fa fa-mobile login-user" aria-hidden="true"></i>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-4">
        <div class="login-input-head">
            <p><b>ID NAME:</b></p>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="login-input-area">
            <select>
                <option value = "Select"> --Select--   
                </option>  
                <option value = "Aadhar Card"> Aadhar Card   
                </option>  
                <option value = "Driving license"> Driving License   
                </option>  
                <option value = "Voter Id"> Voter Id  
                </option>  
                <option value = "Passport"> Passport  
                </option>  
                </select>  
            <i class="fa fa-lock login-user"></i>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-4">
        <div class="login-input-head">
            <p><b>ID NUMBER:</b></p>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="login-input-area">
            <input type="number" name="id_number" required="true" />
            <i class="fa fa-lock login-user"></i>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-4">
        <div class="login-input-head">
            <p><b>USERNAME:</b></p>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="login-input-area">
            <input type="varchar" name="username" required="true" />
            <i class="fa fa-lock login-user"></i>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-4">
        <div class="login-input-head">
            <p><b>PASSWORD:</b></p>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="login-input-area">
            <input type="password" name="password" required="true" />
            <i class="fa fa-lock login-user"></i>
        </div>
    </div>
</div>

<input type="checkbox" id="t&c" name="t&c" value="t&c">
<label for="t&c"> I have read all the terms and conditions before filling this reisteration form and all information filled by me is genuine.</label><br>

<div class="row">
    <div class="col-lg-4"></div>
    <div class="col-lg-8">
        <div class="login-keep-me register-check">
                <p>
            <small>Already have an account ?</small>
            <a href="login.php">LOG IN</a>
                </p>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-4"></div>
    <div class="col-lg-8">
        <div class="login-button-pro">
            
            <button type="submit" class="login-button login-button-lg" name="submit" onClick="showMessage()">REGISTER</button>
            <button type="reset" class="login-button login-button-lg" name="submit">RESET</button>
            <script type="text/javascript">
            function showMessage() {
                alert("Thnank you for registration.");
            }
        </script>
        </div>
    </div>
</div>
</div>
</div>
</form>
</div>
<div class="fancy-hero-area bg-img bg-overlay animated-img" style="background-image: url(image/bg-img/a.jpg);"></div>  
<?php
    if(isset($_POST['submit'])){
        $count=0;
        $sql='SELECT username from register';
        $res=mysqli_query($db,$sql);

        while($row=mysqli_fetch_assoc($res)){
            if($row['username']==$_POST['username']){
                $count=$count+1;
            }
        }

    if($count==0){
        mysqli_query($db,"INSERT INTO `register` VALUES ('$_POST[sname]','$_POST[dob]','$_POST[gender]',
        '$_POST[id]','$_POST[id_number]','$_POST[username]',
        '$_POST[password]')");
        ?>
            <script type="text/javascript">
                alert("Registration Successfull");
                window.location="login.php";
            </script>
        <?php
        }
        else{
        ?>
            <script>
                alert("The username alerady exists");
            </script>
        <?php
        }
    }  
?>          
</body>
</html>