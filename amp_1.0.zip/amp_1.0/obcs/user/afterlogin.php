<?php
    include "connection.php";
?>

<html>
<head> 
<title>User | Air MP</title>
<!-- Core Stylesheet -->
<!-- <link href="style2.css" rel="stylesheet"> -->
<link rel="stylesheet" href="style1.css">
<style>
        .button{
            text-align: center;
            margin-top: 3%;
            transition: 0.3s ease;
            animation: animatebutt linear infinite;
        }
        .btn:hover{
            background-color: white;
            color: aqua;
            transform: scale(2.25px);
        }
        @keyframes butt {
            0%{
                transform: translateY(-25px);
            }
            50%{
                transform: translateY(25px);
            }
        }
    </style>
</head>

<body>
<!-- ***** Header Area Start ***** -->
<header class="header_area" id="header">
    <div class="col-12 h-100">
        <nav class="h-100 navbar navbar-expand-lg align-items-center">
            <a class="navbar-brand" href="../index.php">Air MP</a>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="../index.php"><b>HOME</b> <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="register.php"><b>REGISTERATION</b></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="bookflight.php"><b>Book </b></a>
                </li>
                <!-- <li class="nav-item">
                    <a class="nav-link" href="login.php"><b>LOGIN</b></a>
                </li> -->
                <!-- <li class="nav-item">
                    <a class="nav-link" href="user/events.php"><b>OUR EVENTS</b></a>
                </li> -->
                <li class="nav-item">
                    <a class="nav-link" href="about.php"><b>ABOUT US</b></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="contact.php"><b>CONTACT US</b></a>
                </li>
            </ul>
        </nav>     
    </div>
    <h2 style="color:white; font-family: Georgia, 'Times New Roman', Times, serif; text-align:center; margin-top: 15%;">Fly your dreams with us!</h2>
    <div class="button">
        <form action="bookflight.php">
        <h1 ><a href="bookflight.php">Bookflight</a></h1>
     
      </form>
    </div>
    </header>
<div class="fancy-hero-area bg-img bg-overlay animated-img" style="background-image: url(image/bg-img/afterlogin.jpg);">
</div>
</body>
</html>