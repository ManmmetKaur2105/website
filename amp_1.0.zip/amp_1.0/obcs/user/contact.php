<!DOCTYPE html>
<html>

<head>
    
    <title>Contact Us - Air MP</title>


    <!-- Core Stylesheet -->
    <link href="style.css" rel="stylesheet">
    <link href="style1.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.4/css/fontawesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css">
   </head>

<body>
      <!-- ***** Header Area Start ***** -->
    <header class="header_area" id="header">
                     <div class="col-12 h-100">
                    <nav class="h-100 navbar navbar-expand-lg align-items-center">
                        <a class="navbar-brand" href="index.php">Air MP</a>
                             <ul class="navbar-nav ml-auto">
                                <li class="nav-item active">
                                    <a class="nav-link" href="../index.php"><b>HOME</b> <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="register.php"><b>REGISTERATION</b></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="login.php"><b>LOGIN</b></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="about.php"><b>ABOUT US</b></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php"><b>CONTACT US</b></a>
                                </li>
                                 </ul>
                         
                  </nav>     
        </div>
        <h1 style="color:white; text-align:left; margin-top: 3%; font-weight: 600; font-family: Georgia, 'Times New Roman', Times, serif;">CONTACT US</h1>
        <div class="wrapper">
            
        
            <h3 style="text-align: left; margin-top: 3%; color: white;"><u>Social Media</u></h3>
            <p style=" color: white; text-align: left; margin-top: 2%;"> <a href="https://www.facebook.com/" target="_blank"><i class="fa-brands fa-square-facebook"></i></a>  Follow us on facebook @airMP</p>
            <p style=" color: white; text-align: left; margin-top: 2%;"> Follow us on instagram @air_MP</p>
            <p style=" color: white; text-align: left; margin-top: 2%;"> Follow us on twitter @airmp</p>
            <div class="media">
                <ul>
                
                    <li><i class="fa-brands fa-instagram-square"></i></li>
                    <li><i class="fa-brands fa-twitter-square"></i></li>
                </ul>
            </div>
        </div>
    </header>

     <div class="fancy-hero-area bg-img bg-overlay animated-img" style="background-image: url(image/bg-img/contact.jpg);">
    
      </div>
	  
</body>
</html>