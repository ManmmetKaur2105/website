<!DOCTYPE html>
<html>

<head>
    
    <title>About Us - Air MP</title>


    <!-- Core Stylesheet -->
    <link href="style.css" rel="stylesheet">
    <link href="style1.css" rel="stylesheet">
   </head>

<body>
      <!-- ***** Header Area Start ***** -->
    <header class="header_area" id="header">
                     <div class="col-12 h-100">
                    <nav class="h-100 navbar navbar-expand-lg align-items-center">
                        <a class="navbar-brand" href="index.php">Air MP</a>
                             <ul class="navbar-nav ml-auto">
                                <li class="nav-item active">
                                    <a class="nav-link" href="../index.php"><b>HOME</b> <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="register.php"><b>REGISTERATION</b></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="login.php"><b>LOGIN</b></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="about.php"><b>ABOUT US</b></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact.php"><b>CONTACT US</b></a>
                                </li>
                                 </ul>
                         
                  </nav>     
        </div>
        <h1 style="color:white; text-align:center; margin-top: 8%; font-weight: 600; font-family: Georgia, 'Times New Roman', Times, serif;">ABOUT US</h1>
        <p style="color:white; font-weight: 600; font-family:'Times New Roman', Times, serif;">Since new domestic airports are being built on a bigger scale within a state, air ticket booking will be much easier as even small airlines will be seen on our website-Air MP.
        The flights in the state will be much cheaper as the commission for ticket will be much less than all other big websites who aim for major profit building.
         Air Mp focuses on providing cheap/affordable airlines while travelling within the state.
         Another major aim of our airlines is to promote tourism of our state MP.</p>
    </header>
     <div class="fancy-hero-area bg-img bg-overlay animated-img" style="background-image: url(image/bg-img/ab.jpg);">
    
      </div>
	  
</body>
</html>